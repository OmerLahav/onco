<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SymptomReportsController extends Controller
{
    //
   
}

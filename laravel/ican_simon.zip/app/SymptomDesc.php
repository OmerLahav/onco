<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SymptomDesc extends Model
{
    public $timestamps = false;
    protected $table = 'symptom_desc'; 
}

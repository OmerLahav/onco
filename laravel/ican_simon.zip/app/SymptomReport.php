<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SymptomReport extends Model
{
    public $timestamps = true;
    protected $table = 'symptom_reports'; 
}

$(document).ready(function(){
  $(".sidebar").height( $("main").height()+9);
});

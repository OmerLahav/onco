<?php

return [
'login' =>'логин'

];
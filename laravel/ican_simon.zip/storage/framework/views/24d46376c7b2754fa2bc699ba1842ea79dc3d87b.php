<?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="page-wrapper-container">
        <h1>Medications log</h1>
        <div class="steps">
            <ol class="direction">
                <li>
                    Here you will review medications reports of your patients.
                </li>

            </ol>
        </div>
        <table id="example" class="table table-striped table-bordered col-sm-12" style="width:100%">
            <thead>
            <tr>
                <th>Patient Name</th>
                <th>Treatment</th>
                <th>Medication</th>
                <th>Date</th>
                <th>Day Part</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($value >= date('Y-m-d',strtotime($treatment->created_at)) && $value <= date('Y-m-d',strtotime($treatment->ends_at))): ?>
                        <?php if(!isset($treatment->medications) && empty($treatment->medications)): ?>
                            <?php
                            $treatment->medications = App\TreatmentMedication::where('treatment_id',$treatment->id)->get();
                            ?>
                        <?php endif; ?>
                          <?php $__currentLoopData = $treatment->medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment_medication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(date('Y-m-d H:i:s',strtotime($treatment->ends_at)) >= date('Y-m-d H:i:s')): ?>
                        <tr>
                            <?php if(!empty($treatment->patient)): ?>
                                <td><?php echo e($treatment->patient->name); ?></td>
                            <?php else: ?>
                                
                                <?php if(isset($treatment->patient_id) && $treatment->patient_id > 0): ?>
                                
                                    <?php
                                        $patients = App\User::where('id','=',$treatment->patient_id)->first();
                                    ?>
                                    
                                    <?php if(!empty($patients)): ?>
                                     <td><?php echo e($patients->first_name); ?> <?php echo e($patients->last_name); ?></td>
                                    <?php else: ?>
                                         <td>--N/A--</td>
                                    <?php endif; ?>
                                <?php else: ?>
                                   <td>--N/A--</td>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php

                                $is_taken = App\MedicationLog::whereIn('patient_id', $treatments->pluck('patient_id')->unique()->toArray())
                                        ->where(DB::raw("DATE(medication_logs.created_at)"),"=",$value)
                                        ->where('treatment_medication_id', $treatment_medication->id)
                                        ->count()
                                       
                            ?>
                           <td><?php echo e($treatment->name); ?></td>
                            <td><?php echo e($treatment_medication->medication->name); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($value)->format('d/m/Y')); ?></td>
                            <td><?php echo e(App\TreatmentMedication::DAY_PARTS[$treatment_medication->day_part]); ?></td>
                            <td><?php echo e($is_taken > 0 ? 'Taken' : 'Not taken'); ?>

                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </div>
</div>

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin-styles/pages/admin-index.css')); ?> ">


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.portal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
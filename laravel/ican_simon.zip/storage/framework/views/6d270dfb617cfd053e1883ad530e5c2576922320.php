<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="page-wrapper-container">
            <h1>All symptoms</h1>
             <a href="<?php echo e(route('symptoms.create')); ?>" class="btn btn-info add-btn bg-info"><i class="fas fa-plus"></i>Add</a>
            <div class="steps">
                <ol class="direction">
                    <li>
                        On this page you can add new symptoms.
                    </li>
                    <li>
                        Please fill all the information below.
                    </li>
                </ol>
            </div>
            <table id="symptom-index" class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th>Sr #</th>
                    <th>Symptom Name</th>
                   <!--  <th>Symptom Image</th> -->
                    <th>Importance Level</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $symptom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($symptom->id); ?></td>
                        <td><?php echo e($symptom->name); ?></td>
                        <!-- <td><img src="<?php echo e(public_path()); ?>/images/symptoms/<?php echo e($symptom->image); ?>" height="10" width="10" ></td> -->
                        <td><?php echo e($symptom->importance_level); ?></td>
                        <td>
                            <a href="<?php echo e(action('SymptomsController@Symp_edit',$symptom->id)); ?>"  class="btn btn-primary opt-btn fa fa-edit"><span class="edit "> Edit </span></a>
                            <a href="/Symp_delete/<?php echo e($symptom->id); ?>"  onclick="return confirm('Are you sure you want to delete this symptom?');" class="btn btn-danger opt-btn far fa-trash-alt"><span class="edit del">Delete</span></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin-styles/pages/admin-index.css')); ?> ">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
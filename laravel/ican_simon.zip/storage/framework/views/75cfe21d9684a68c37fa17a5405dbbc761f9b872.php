<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="page-wrapper-container">
            <h1>All Staff</h1>
            <?php if(Auth::user()->isAdmin()): ?>
              <a href="<?php echo e(route('team.create')); ?>" class="btn btn-info add-btn bg-info"><i class="fas fa-plus"></i>Add</a>
            <?php endif; ?>
             <div class="steps">
                <ol class="direction">
                    <li>
                        On this page you can add/edit/delete team stuff.
                    </li>
             
            </div>
            <table id="team"  class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>Identification Number</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Role</th>
                    <?php if(Auth::user()->isAdmin()): ?>
                    <th>Actions</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if((Auth::user()->isAdmin() && !$member->isAdmin()) || Auth::user()->isDoctor()): ?>
                    
	                    <tr>
	                        <td><?php echo e($member->name); ?></td>
	                        <td><?php echo e($member->identification_number); ?></td>
	                        <td><?php echo e($member->email); ?></td>
	                        <td><?php echo e($member->phone); ?></td>
	                        <td><?php echo e((new App\User)->getRoleName($member->role)); ?></td>
                            <?php if(Auth::user()->isAdmin()): ?>
	                        <td>
	                            <a href="<?php echo e(action('TeamController@Team_edit',$member->id)); ?>"  class="btn btn-primary opt-btn fa fa-edit"><span class="edit "> Edit </span></a>
	                            <a href="/Team_delete/<?php echo e($member->id); ?>"  onclick="return confirm('Are you sure you want to delete this staff member?');" class="btn btn-danger opt-btn far fa-trash-alt"><span class="edit del">Delete</span></a>
	                        </td>
                            <?php endif; ?>
	                    </tr>
	           
                   <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin-styles/pages/admin-index.css')); ?> ">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.portal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
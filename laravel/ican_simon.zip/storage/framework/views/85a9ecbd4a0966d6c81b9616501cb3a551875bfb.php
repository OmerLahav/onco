<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="page-wrapper-container">
            <h1>Appointments</h1>
            <?php if(Auth::user()->isPatient() || Auth::user()->isSecratory()): ?>
                <a href="<?php echo e(route('appointments.create')); ?>" class="btn btn-info add-btn bg-info"><i class="fas fa-plus"></i>Add</a>
            <?php endif; ?>
             <div class="steps">
                <ol class="direction">
                    <li>
                        On this page, you can review  your appointments.
                    </li>
                    <?php if(Auth::user()->isPatient() || Auth::user()->isSecratory()): ?>
                    <li>
                        In addition, you can add the appointment to your Google Calendar by pressing on the "G ADD" button.
                    </li>
                     <?php endif; ?>
                </ol>
            </div>

            
            <table id="appointments" id="appointments2" class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th>ID</th>
                   <!--  <?php if(Auth::user()->isPatient() || Auth::user()->isSecratory()  || Auth::user()->isNurse()  || Auth::user()->isAdmin()): ?> -->
                        <th>Provider Name</th>
                   <!--  <?php endif; ?> -->
                    <?php if(!Auth::user()->isPatient()): ?>
                     <th>Patient Name</th>
                    <?php endif; ?>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Type </th>
                    <?php if(Auth::user()->isPatient() || Auth::user()->isSecratory()): ?>
                        <th>Actions</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($appointment->id); ?></td>
                        <?php if(Auth::user()->isPatient() || Auth::user()->isSecratory() || Auth::user()->isNurse() || Auth::user()->isAdmin()): ?>
                            <?php if($appointment->medical_staff_id != "" && $appointment->medical_staff_id > 0): ?>
                               <td><?php echo e($appointment->provider->first_name . ' ' . $appointment->provider->last_name); ?></td>
                            <?php else: ?>
                                <td>--N\A--</td>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(!Auth::user()->isPatient()): ?>
                            <?php if(isset($appointment->patient->first_name) && isset($appointment->patient->last_name)): ?>
                                <td><?php echo e($appointment->patient->first_name . ' ' . $appointment->patient->last_name); ?> </td>
                            <?php else: ?>
                                <td>--N\A--</td>
                            <?php endif; ?>
                        <?php endif; ?>

                        <td><?php echo e(date('d-m-Y', strtotime($appointment->appointment_date))); ?></td>
                        <td><?php echo e(date('H:i', strtotime($appointment->appointment_time))); ?></td>
                        <td><?php echo e($appointment->status); ?></td>
                        <td><?php echo e($appointment->medical_staff_type); ?></td>
                        <?php if(Auth::user()->isPatient() || Auth::user()->isSecratory() || Auth::user()->isNurse() || Auth::user()->isAdmin()): ?>
                            <td>

                           <!--  edit --> 
                             <!--   <?php if(!Auth::user()->isPatient()): ?>
                                 <a href="<?php echo e(action('AppointmentsController@editAppointments',$appointment->id)); ?>"  class="btn btn-primary opt-btn fa fa-edit"><span class="edit "> Edit </span></a>
                                <?php endif; ?>  -->

                                <a href="/appointments/<?php echo e($appointment->id); ?>/delete"  onclick="return confirm('Are you sure you want to delete this appointment?');" class="btn btn-danger opt-btn far fa-trash-alt"><span class="edit del">Delete</span></a>
                              
                                <?php if($appointment->medical_staff_id != "" && $appointment->medical_staff_id > 0): ?>

                                    <form class="form cf" method="POST" action="<?php echo e(route('api.google_calender_for_book_appoinment')); ?>">
                                     <?php echo csrf_field(); ?>
                                     <input type="hidden" value="<?php echo e($appointment->appointment_date); ?>" name="appointment_date">

                                     <input type="hidden" value="<?php echo e($appointment->provider->first_name . ' ' . $appointment->provider->last_name); ?>" name="provider_name" >
                                     
                                     <input type="hidden" value="<?php echo e($appointment->appointment_time); ?>" name="appointment_time">
                                     <button  type="submit" class="btn g-btn btn-primary "><i class="fab fa-google"></i>Add</button>
                                   </form>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
     <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin-styles/pages/admin-index.css')); ?> ">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
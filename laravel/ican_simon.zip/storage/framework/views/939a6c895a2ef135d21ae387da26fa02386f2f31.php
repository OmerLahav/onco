<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="page-wrapper-container">
            <h1>Schedule</h1>
            
            <?php if(Auth::user()->isSecratory()): ?>

                <a href="<?php echo e(route('slots_time.create')); ?>" class="btn btn-info add-btn bg-info"><i class="fas fa-plus"></i>Add
                </a>

                <div class="steps">
                    <ol class="direction">
                        <li>
                            On this page you can add a new slot's for the doctors.
                        </li>
                        <li>
                            Press the "ADD" button to add.
                        </li>
                    </ol>
                </div>
            <?php endif; ?>
            <?php if(Auth::user()->isDoctor()): ?>
               <div class="steps">
                    <ol class="direction">
                        <li>
                            On this page you can add see your available slots and their date.
                        </li>
                    
                    </ol>
                </div> 
            <?php endif; ?>
            <table id="slots" class="table table-striped table-bordered col-sm-12 " style="width:100%">
                <thead>
                <tr>
                    <th>ID</th>
                    <?php if(Auth::user()->isSecratory()): ?>
                        <th>Provider</th>
                    <?php endif; ?>
                    <th>Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Type</th>
                    <th>Slot Time</th>
                    <?php if(Auth::user()->isSecratory()): ?>
                        <th>Actions</th>
                    <?php endif; ?>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $timeslots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeslot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <tr>
                        <td><?php echo e($timeslot->id); ?></td>
                        
                        <?php if(Auth::user()->isSecratory()): ?>

                            <?php if($timeslot->user_id != "" && $timeslot->user_id > 0): ?>
                               <td><?php echo e($timeslot->provider->first_name . ' ' . $timeslot->provider->last_name); ?></td>
                            <?php else: ?>
                                <td>--N\A--</td>
                            <?php endif; ?>

                        <?php endif; ?>

                        
                        <!-- <td><?php echo e($timeslot->slot_date); ?></td>-->
                        <td><?php echo e(\Carbon\Carbon::parse($timeslot->slot_date)->format('d/m/Y')); ?></td>
                        <td><?php echo e($timeslot->start_time); ?></td>
                        <td><?php echo e($timeslot->end_time); ?></td>
                        <td><?php echo e($timeslot->type); ?></td>
                        <td><?php echo e($timeslot->slot_time_in_minute); ?></td>
                        <?php if(Auth::user()->isSecratory()): ?>

                        <td>
                            <a href="<?php echo e(action('SloteTimeController@Slot_edit',$timeslot->id)); ?>"  class="btn btn-primary opt-btn fa fa-edit" style="margin-bottom:5px;"><span class="edit "> Edit </span></a>
                            <a href="/Slot_delete/<?php echo e($timeslot->id); ?>"  onclick="return confirm('Are you sure you want to delete this timeslot?');" class="btn btn-danger opt-btn far fa-trash-alt"><span class="edit del">Delete</span></a>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

	<!--css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin-styles/pages/admin-index.css')); ?> ">
	<link href="<?php echo asset('css/data-tables.css'); ?>" media="all" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
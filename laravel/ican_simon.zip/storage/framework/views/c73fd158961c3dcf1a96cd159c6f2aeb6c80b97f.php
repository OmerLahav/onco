<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="page-wrapper-container">
            <h1>All medications</h1>
            
            <div class="steps">
                <ol class="direction">
                    <li>
                        On this page, you can add new medications.
                    </li>
                    <li>
                        You need to choose the right memedication and its strength.
                    </li>
                </ol>
            </div>
            <a href="<?php echo e(route('medications.create')); ?>"  class="btn btn-info add-btn bg-info"><i class="fas fa-plus"></i>Add</a>
        <!--<table>
		<?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($medication->id); ?></td>
				<td><?php echo e($medication->name); ?></td>
				<td><?php echo e($medication->strength); ?></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>-->

            <table id="medication-index" class="table table-striped table-bordered" style="width:100%">
                <thead>
                <tr>
                    <th>Sr #</th>
                    <th>Medication Name</th>
                    <th>Strength</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $medications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($medication->id); ?></td>
                        <td><?php echo e($medication->name); ?></td>
                        <td><?php echo e($medication->strength); ?></td>
                        <td>
                            <a href="<?php echo e(action('MedicationsController@edit',$medication->id)); ?>"  class="btn btn-primary opt-btn fa fa-edit"><span class="edit "> Edit </span></a>
                            <a href="/Symp_delete/<?php echo e($medication->id); ?>"  onclick="return confirm('Are you sure you want to delete this medication?');" class="btn btn-danger opt-btn far fa-trash-alt"><span class="edit del">Delete</span></a>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin-styles/pages/admin-index.css')); ?> ">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
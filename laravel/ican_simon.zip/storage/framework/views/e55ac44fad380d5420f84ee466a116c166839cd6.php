<?php $__env->startSection('content'); ?>

<div class="page-wrapper">
    <div class="page-wrapper-container">
        <h1>Symtoms log</h1>
        <div class="steps">
            <ol class="direction">
                <li>
                    Here you can review symptoms' reports of your patients.
                </li>

            </ol>
        </div>
        <table id="symp-report" class="table table-striped table-bordered col-sm-12" style="width:100%" >
            <thead>
            <tr>
                <th>Patient Name</th>
                <th>Treatment</th>
                <th>Symptom Name</th>
                <th>Level</th>
                <th>Date</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($value >= date('Y-m-d',strtotime($treatment->created_at)) && $value <= date('Y-m-d',strtotime($treatment->ends_at))): ?>
                        <?php if(!isset($treatment->symptoms) && empty($treatment->symptoms)): ?>
                            <?php
                            $treatment->symptoms = App\TreatmentSymtoms::where('treatment_id',$treatment->id)->get();
                            ?>
                        <?php endif; ?>

                        <?php $__currentLoopData = $treatment->symptoms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment_symtoms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(date('Y-m-d H:i:s',strtotime($treatment->ends_at)) >= date('Y-m-d H:i:s')): ?>
                        <tr>
                            <?php if(!empty($treatment->patient)): ?>
                                <td><?php echo e($treatment->patient->name); ?></td>
                            <?php else: ?>
                                
                                <?php if(isset($treatment->patient_id) && $treatment->patient_id > 0): ?>
                                
                                    <?php
                                        $patients = App\User::where('id','=',$treatment->patient_id)->first();
                                    ?>
                                    
                                    <?php if(!empty($patients)): ?>
                                     <td><?php echo e($patients->first_name); ?> <?php echo e($patients->last_name); ?></td>
                                    <?php else: ?>
                                         <td>--N/A--</td>
                                    <?php endif; ?>
                                <?php else: ?>
                                   <td>--N/A--</td>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php
                                $symtoms_reports = [];
                                $symtoms_reports = App\SymptomReport::whereIn('patient_id', $treatments->pluck('patient_id')->unique()->toArray())
                                        ->where(DB::raw("DATE(symptom_reports.created_at)"),"=",$value)
                                        ->where('symptoms_id', $treatment_symtoms->id)
                                        ->where('treatment_id', $treatment->id)
                                        ->first();
                                       
                            ?>
                            
                           <td><?php echo e($treatment->name); ?></td>
                            <td><?php echo e($treatment_symtoms->name); ?></td>
                            <td>
                                 <?php if(!empty($symtoms_reports)): ?>
                                    <?php echo e($symtoms_reports->patient_level); ?>

                                 <?php else: ?>
                                    --
                                 <?php endif; ?>
                            </td>
                            
                            <td><?php echo e(Carbon\Carbon::parse($value)->format('d/m/Y')); ?></td>
                            <td>
                               <?php if(!empty($symtoms_reports)): ?>
                                    Submited
                                 <?php else: ?>
                                    
                                    Not Submited
                                 <?php endif; ?>

                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </div>
</div>



    <script src="<?php echo e(asset('js2/jquery.min.js')); ?>"></script>

</script>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin-styles/pages/admin-index.css')); ?> ">
 
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.portal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>